/*package com.dawes.config;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

@Service
public class MyService {

    @PreAuthorize("hasRole('ADMIN')")
    public String adminOnlyMethod() {
        return "This method is accessible only to users with the 'ADMIN' role";
    }

    @PreAuthorize("hasRole('USER')")
    public String userOnlyMethod() {
        return "This method is accessible only to users with the 'USER' role";
    }

    // Other methods...

}
*/