package com.dawes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFtgApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFtgApplication.class, args);
	}

}
